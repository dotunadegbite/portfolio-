Hello!

Thank you for playing Pong 2.0. First to run the game you must run the main.py script. 
To navigate the home page and the options page you must use the arrow keys and press Enter to select.

Controls:

Player 1/Left Side of keyboard:
-Press A to move up
-Press Z to move down


Player 2/Right Side of keyboard:
-Press UP arrow to move up
-Press DOWN arrow to move down


Enjoy!
