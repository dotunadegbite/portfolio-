import math
import pygame
import random
from pygame.locals import *
from example_menu import main as menu
from options_menu import main as options


border = 50;
# Initialise screen
pygame.init()
screen = pygame.display.set_mode((1280 + 2*border, 720 + 2*border))
pygame.display.set_caption('PONG 2.0')
font = pygame.font.Font(None, 150)
title = font.render('PONG 2.0', 1, (255,255,255))
screen.blit(title, (450, 150))

#Clock and FPS---Pretty stuff----
FPS = 30
clock = pygame.time.Clock()
clock.tick(FPS)
pygame.display.update()




white = pygame.Color(255,255,255)
black = pygame.Color(0,0,0)




class Ball(pygame.sprite.Sprite):
        """A ball that will move across the screen
        Returns: ball object
        Functions: update, calcnewpos
        Attributes: area, vector"""

        def __init__(self, vector):
            pygame.sprite.Sprite.__init__(self)
            screen = pygame.display.get_surface()
            self.image = pygame.image.load('ball.png')
            self.rect = self.image.get_rect()
            self.area = screen.get_rect()
            self.vector = vector
            self.angle = vector[0]
            self.speed = vector[1]
            self.rect.x, self.rect.y = 640+ border, 360+border
            self.isCollide = 0
            pygame.display.flip()



        def update(self):
            newpos = self.calcnewpos(self.rect,self.vector)
            self.rect = newpos
            (self.angle,self.speed) = self.vector

            if not self.area.contains(newpos):
                topleft = not self.area.collidepoint((newpos.topleft[0] + border , newpos.topleft[1] + border))
                topright = not self.area.collidepoint((newpos.topright[0]-border, newpos.topright[1] + border)) 
                bottomleft = not self.area.collidepoint((newpos.bottomleft[0] + border, newpos.bottomleft[1] -border)) 
                bottomright = not self.area.collidepoint((newpos.bottomright[0] - border, newpos.bottomright[1]-border))
                if topright and topleft or (bottomright and bottomleft):
                    self.angle = -self.angle
                if topleft and bottomleft:
                    my_game.out_of_bounds(player2)
                    self.angle = math.pi - self.angle
                if topright and bottomright:
                    self.angle = math.pi - self.angle
                    my_game.out_of_bounds(player1)
            else:
                # Deflate the rectangles so you can't catch a ball behind the bat
                player1.rect.inflate(-5, -3)
                player2.rect.inflate(-3, -3)

                if (not self.rect.colliderect(player1.rect)) and (not self.rect.colliderect(player2.rect)):
                    self.isCollide = 0
                elif (self.rect.colliderect(player1.rect) or self.rect.colliderect(player2.rect)) and self.isCollide == 0:
                    self.isCollide = 1
                if self.isCollide == 1:
                    if ((self.rect.colliderect(player1.rect) and self.rect.bottom >= player1.rect.top and self.rect.bottom <= (player1.rect.top + 20)) or (self.rect.colliderect(player1.rect) and self.rect.top <= player1.rect.bottom and self.rect.top >= (player1.rect.bottom - 20))) or (self.rect.colliderect(player2.rect) and self.rect.bottom >= player2.rect.top and self.rect.bottom <= (player2.rect.top + 20)) or (self.rect.colliderect(player2.rect) and self.rect.top <= player2.rect.bottom and self.rect.top >= (player2.rect.bottom - 20)):
                        self.angle = self.angle + math.pi
                    else:
                        self.angle = math.pi - self.angle
                    if self.rect.colliderect(player1.rect) or self.rect.colliderect(player2.rect):
                        self.isCollide = 2        
            self.vector = (self.angle,self.speed)

        def calcnewpos(self,rect,vector):
                (self.angle,self.speed) = vector
                (dx,dy) = (self.speed*math.cos(self.angle),self.speed*math.sin(self.angle))
                return rect.move(dx,dy)

class Paddle(pygame.sprite.Sprite):
        """Movable tennis 'bat' with which one hits the ball
        Returns: bat object
        Functions: reinit, update, moveup, movedown
        Attributes: which, speed"""

        def __init__(self, side):
            pygame.sprite.Sprite.__init__(self)
            self.image = pygame.image.load('bat.png')
            self.rect = self.image.get_rect()
            screen = pygame.display.get_surface()
            self.area = screen.get_rect()
            self.side = side
            self.speed = 7
            self.state = "still"
            self.reinit()

        def reinit(self):
            self.state = "still"
            self.movepos = [0,0]
            if self.side == "left":
                    print self.area.midleft
                    self.rect.midleft = (0 + border,360+border)
            elif self.side == "right":
                    print self.area.midright
                    self.rect.midright = (1280 + border,360+border)

        def update(self):
            newpos = self.rect.move(self.movepos)
            if self.area.contains(newpos):
                    self.rect = newpos
            pygame.event.pump()

        def moveup(self):
            self.movepos[1] = self.movepos[1] - (self.speed)
            self.state = "moveup"

        def movedown(self):
            self.movepos[1] = self.movepos[1] + (self.speed)
            self.state = "movedown"



class Ball2(Ball):
    def __init__(self, vector):
        pygame.sprite.Sprite.__init__(self)
        screen = pygame.display.get_surface()
        self.image = pygame.image.load('ball.png')
        self.rect = self.image.get_rect()
        self.area = screen.get_rect()
        self.vector = vector
        self.angle = vector[0]
        self.speed = vector[1]
        self.rect.x, self.rect.y = 640+ border, 200+border
        self.hit = 0
        pygame.display.flip()





class Game(object):

    def __init__(self, screen):
        self.screen = screen
        global player1
        global player2
        player1 = Paddle("left")
        player2 = Paddle("right")
        self.player1_score = 0
        self.player2_score = 0
        self.speed = 7
        self.rand = random.randint(0,3)
        if self.rand == 1:
            self.direction = math.pi / 4
        elif self.rand == 2:
            self.direction = 3 * math.pi / 4
        elif self.rand == 3:
            self.direction = 5 * math.pi / 4
        else:
            self.direction = 7 * math.pi / 4
            
        self.ball = Ball((self.direction, self.speed))
        self.ball2 = Ball2((-self.direction + 90, self.speed))
        self.playersprites = pygame.sprite.RenderPlain((player1, player2))
        self.ballsprite = pygame.sprite.RenderPlain(self.ball,self.ball2)
        self.background = pygame.Surface(screen.get_size())
        self.background = self.background.convert()
        self.background.fill((0, 0, 0))
        screen.blit(self.background, (0, 0))
        pygame.display.flip()

    def texts(self):
        font = pygame.font.Font(None, 30)
        font2 = pygame.font.Font(None, 60)
        score1 = font.render("Score: " + str(self.player1_score), 1, white,black)
        score1Rect = score1.get_rect()
        score2 = font.render("Score: " + str(self.player2_score), 1, white,black)
        score2Rect = score2.get_rect()
        screen.blit(score1, (player1.rect.x + 300 + border , 30 + border))
        screen.blit(score2,(player2.rect.x - 300 + border, 30 + border))


    
    


        
    def out_of_bounds(self, player):
        self.rand = random.randint(0,3)
        if self.rand == 1:
            self.direction = math.pi / 4
        elif self.rand == 2:
            self.direction = 3 * math.pi / 4
        elif self.rand == 3:
            self.direction = 5 * math.pi / 4
        else:
            self.direction = 7 * math.pi / 4

        temp_score1 = self.player1_score
        temp_score2 = self.player2_score
    
        if self.ball.rect.x < 10 + border or (self.ball2.rect.x < 10 + border):
            self.ball.kill()
            self.ball2.kill()
            self.player2_score += 1
            self.ball = Ball((self.direction,self.speed))
            self.ball2 = Ball2((-self.direction + 90, self.speed))     
        elif self.ball.rect.y > 68 - border or(self.ball2.rect.y > 68 - border):
            self.ball.kill()
            self.ball2.kill()
            self.player1_score += 1
            self.ball = Ball((self.direction,self.speed))
            self.ball2 = Ball2((-self.direction + 90, self.speed)) 



        self.ballsprite = pygame.sprite.RenderPlain(self.ball,self.ball2)
        screen.blit(self.background, self.ball.rect, self.ball.rect)
        screen.blit(self.background, self.ball2.rect, self.ball2.rect)
        screen.blit(self.background, player1.rect, player1.rect)
        screen.blit(self.background, player2.rect, player2.rect)
        self.ballsprite.draw(screen)
        self.playersprites.draw(screen)
        pygame.display.flip()
        pygame.time.delay(2000)

   




    def options_menu(self,screen):
        font2 = pygame.font.Font(None, 60)
        header= font2.render("CHOOSE DIFFICULTY",1,white,black)
        screen.blit(header,(490,100))
        pygame.display.flip()
        results = options(screen)
        if results == 5:
            self.ball.speed = results
            self.speed = results
            self.ball = Ball((self.direction, self.speed))
            self.ball2 = Ball2((-self.direction + 90, self.speed))
            self.ballsprite = pygame.sprite.RenderPlain(self.ball,self.ball2)
            self.background = pygame.Surface(screen.get_size())
            self.background = self.background.convert()
            self.background.fill((0, 0, 0))
            screen.blit(self.background, (0, 0))
            pygame.display.flip()
            self.play()
        elif results == 7:
            self.speed = results
            self.ball = Ball((self.direction, self.speed))
            self.ball2 = Ball((-self.direction + 90, self.speed))
            self.ballsprite = pygame.sprite.RenderPlain(self.ball, self.ball2)
            self.background = pygame.Surface(screen.get_size())
            self.background = self.background.convert()
            self.background.fill((0, 0, 0))
            screen.blit(self.background, (0, 0))
            pygame.display.flip()
            self.play()
        elif results == 10:
            self.speed = results
            self.ball = Ball((self.direction, self.speed))
            self.ball2 = Ball((-self.direction + 90, self.speed))
            self.ballsprite = pygame.sprite.RenderPlain(self.ball, self.ball2)
            self.background = pygame.Surface(screen.get_size())
            self.background = self.background.convert()
            self.background.fill((0, 0, 0))
            screen.blit(self.background, (0, 0))
            pygame.display.flip()
            self.play()

        
    def view_scores(self,screen):
        font2 = pygame.font.Font(None, 60)
        self.background = pygame.Surface(screen.get_size())
        self.background = self.background.convert()
        self.background.fill((0, 0, 0))
        screen.blit(self.background, (0, 0))
        pygame.display.flip()
        font = pygame.font.Font(None, 30)
        with open('all_scores.txt', 'r') as f:
            saved_scores = f.read()
        f.close()
        scores = font2.render(saved_scores, 1, white,black)
        header = font2.render("PREVIOUS SCORE",1,white,black)
        start_game = font2.render("PRESS SPACE TO PLAY",1,white,black)
        leave_game = font2.render("PRESS ESCAPE TO QUIT",1,white,black)
        screen.blit(scores, (230,150))
        screen.blit(header,(440,50))
        screen.blit(start_game,(440,500))
        screen.blit(leave_game,(440,550))
        pygame.display.flip()
        while True:
            for event in pygame.event.get():
                if event.type == KEYDOWN:
                    if event.key == K_SPACE:
                        self.background = pygame.Surface(screen.get_size())
                        self.background = self.background.convert()
                        self.background.fill((0, 0, 0))
                        screen.blit(self.background, (0, 0))
                        pygame.display.flip()
                        self.play()
                        return
                    if event.key == K_ESCAPE:
                        return

    def play(self):
        events = pygame.event.get()
        event_types = [event.type for event in events]
        while pygame.QUIT not in event_types:
            for event in pygame.event.get():
                if event.type == QUIT:
                    return
                elif event.type == KEYDOWN:
                    if event.key == K_a:
                            player1.moveup()
                    if event.key == K_z:
                            player1.movedown()
                    if event.key == K_UP:
                            player2.moveup()
                    if event.key == K_DOWN:
                            player2.movedown()
                elif event.type == KEYUP:
                    if event.key == K_a or event.key == K_z:
                        player1.movepos = [0,0]
                        player1.state = "still"
                    if event.key == K_UP or event.key == K_DOWN:
                        player2.movepos = [0,0]
                        player2.state = "still"
            events = pygame.event.get()
            event_types = [event.type for event in events]
            screen.blit(self.background, self.ball.rect, self.ball.rect)
            screen.blit(self.background, self.ball2.rect, self.ball2.rect)
            screen.blit(self.background, player1.rect, player1.rect)
            screen.blit(self.background, player2.rect, player2.rect)
            self.ballsprite.update()
            self.playersprites.update()
            self.ballsprite.draw(screen)
            self.playersprites.draw(screen)
            self.texts()
            pygame.display.flip()
            with open('all_scores.txt', 'w') as f:
                f.write("Player 1 Score: " + str(self.player1_score) + "                "
                    + "Player 2 Score: " + str(self.player2_score))
            f.close()





result = menu(screen)
my_game = Game(screen)
if result is None:
    my_game.play()
elif result == 2:
    my_game.view_scores(screen)
elif result == 3:
    my_game.options_menu(screen)





        